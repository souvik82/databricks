---
name: domain-healthcare-claims
description: Business glossary, data model notes and the catalog of claim-processing business rules. Included by every other skill.
engine: none
inputs: []
version: 1
---
## Domain context: payer healthcare claims (synthetic data, no PHI)

Catalog `sentinel_hc`. Layers: `raw` (source) -> `silver.claim_line_enriched` (claim-line grain) -> `gold.claims_kpi_monthly`.
Sandbox copies of old/new logic are `sentinel_hc.sandbox.<target>_baseline` (OLD logic) and `<target>_candidate` (NEW logic).

### Glossary
- **Claim version**: claims are adjudicated more than once. `claim_header(claim_id, claim_version)` is the key; only the LATEST version counts.
- **Eligibility span**: `member_eligibility` has one row per coverage period. A member may have several spans (plan change, late start). A claim is payable only if `service_from_date` falls between `eff_date` and `term_date`, and the plan priced is the plan of that span.
- **Billed amount**: provider charge. **Allowed amount**: lesser of billed and contracted fee (`ref_cpt.fee_schedule_amount` x units); 0 for DENIED.
- **Member cost share**: copay for E&M visits (primary-care vs specialist copay), otherwise coinsurance x allowed; out-of-network (`network_status = 'OUT'`) doubles coinsurance, capped at 100% of allowed. Never exceeds allowed.
- **Plan paid** = allowed - member cost share.
- **VOID** claims are cancelled and must never appear in silver or gold. **DENIED** lines stay visible with zero allowed and zero plan paid.
- **Denial rate** = denied lines / all lines. **avg_paid_per_claimant** = plan paid / distinct claimants in the month.

## Rule catalog
- Voided claims (claim_status = 'VOID') must not appear in the output.
- Each claim_line_key must appear exactly once in the output.
- Every output row must be covered by a member eligibility span that contains the service_from_date and has the same plan_id as the output row.
- allowed_amount must never exceed billed_amount.
- allowed_amount must never exceed the contracted fee schedule amount times units for the cpt_code.
- plan_paid_amount plus member_cost_share must equal allowed_amount.
- DENIED lines must have allowed_amount = 0 and plan_paid_amount = 0.
- Only the latest claim_version of each claim may be represented.
