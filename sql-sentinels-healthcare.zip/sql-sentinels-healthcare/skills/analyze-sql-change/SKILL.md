---
name: analyze-sql-change
description: Understand a SQL change in business terms, extract testable business rules and risks.
engine: genie
fallback_engine: llm
inputs: [target, old_facts, new_facts, structural_diff, downstream, old_sql, new_sql]
output: json
version: 1
---
{{> domain-healthcare-claims}}

## Task
You are a senior healthcare data QA engineer. Two versions of the SQL that builds `{{target}}` are given.
Work out what changed in BUSINESS terms and which business rules the NEW logic must still satisfy.
Answer with plain text containing ONLY one JSON object. Do not write SQL and do not query data.

STRUCTURAL FACTS (parser output)
OLD: {{old_facts}}
NEW: {{new_facts}}
STRUCTURAL DIFF: {{structural_diff}}
DOWNSTREAM OBJECTS (Unity Catalog lineage): {{downstream}}

OLD SQL:
{{old_sql}}

NEW SQL:
{{new_sql}}

## Output contract
{"change_summary": "2-3 sentences in business language (claims, eligibility, allowed amounts ...)",
 "business_rules": ["one testable plain-English rule per item, covering what the new logic changed AND the rules from the rule catalog it could break"],
 "risky_changes": ["technical changes likely to cause regressions, e.g. join predicate removed, filter dropped"],
 "risk_level": "LOW | MEDIUM | HIGH"}
