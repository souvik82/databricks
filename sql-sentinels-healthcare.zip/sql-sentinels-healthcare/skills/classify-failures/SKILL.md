---
name: classify-failures
description: Classify each failed test as expected_change, regression or data_issue and give a root-cause hint.
engine: llm
inputs: [change_summary, rules, failed]
output: json
version: 1
---
{{> domain-healthcare-claims}}

## Task
You are a healthcare data QA lead. A SQL change was made.
CHANGE SUMMARY: {{change_summary}}
BUSINESS RULES: {{rules}}
FAILED TESTS (JSON): {{failed}}

For every failed test choose one label:
- "expected_change": a direct, intended consequence of the described change (e.g. a new column appears)
- "regression": unintended breakage of a business rule (duplicates, wrong amounts, voided claims, lost rows)
- "data_issue": caused by bad source data rather than by the change

Give a one-sentence root-cause hint a claims-data engineer can act on. Return ONLY JSON:
[{"test_id": "", "classification": "expected_change | regression | data_issue", "explanation": ""}]
