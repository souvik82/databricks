---
name: rule-to-validation-sql
description: Turn one business rule into a single validation SELECT that counts violations.
engine: genie
fallback_engine: llm
inputs: [rule, candidate_table, baseline_table]
output: sql
version: 1
---
{{> domain-healthcare-claims}}

## Task
Write ONE Databricks SQL query that validates this business rule on the NEW output table `{{candidate_table}}`
(the old output is `{{baseline_table}}`; use it only if the rule needs a comparison).

RULE: {{rule}}

## Requirements
- Return exactly one row with exactly one integer column named `violations` = the number of rows that VIOLATE the rule. 0 means the rule holds.
- Use fully qualified table names (catalog.schema.table). Source tables are in `sentinel_hc.raw`.
- A single SELECT (or WITH ... SELECT). No DDL, no DML, no semicolons.
