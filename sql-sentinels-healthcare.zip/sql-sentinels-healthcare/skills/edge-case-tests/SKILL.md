---
name: edge-case-tests
description: Propose edge-case regression tests (nulls, duplicates, boundaries, fan-out).
engine: llm
inputs: [candidate_table, baseline_table, columns, rules, risky_changes]
output: json
version: 1
---
{{> domain-healthcare-claims}}

## Task
You are a SQL QA engineer. `{{candidate_table}}` is built by NEW logic, `{{baseline_table}}` by OLD logic.
Columns: {{columns}}
Business rules: {{rules}}
Risky changes: {{risky_changes}}

Propose up to 5 EDGE-CASE regression tests: null handling, duplicate keys, boundary dates (eligibility start/end, year-end),
adjusted claim versions, out-of-network pricing, join fan-out. Each `sql` is one SELECT returning one row with an
integer column `violations` (0 = pass), using the literal table names above (and `sentinel_hc.raw.*` where needed).
Return ONLY a JSON array:
[{"name": "", "category": "edge_case", "sql": "", "severity": "critical | high | medium | low", "rationale": ""}]
