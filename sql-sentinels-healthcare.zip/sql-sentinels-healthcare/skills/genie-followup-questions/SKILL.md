---
name: genie-followup-questions
description: Conversational questions the notebook and App ask Genie after a run. One question per bullet.
engine: genie
inputs: [run_id, target]
output: text
version: 1
---
{{> domain-healthcare-claims}}

## Questions
- For run {{run_id}} in sentinel_hc.meta.test_results, list the failed tests with severity, violations and ai_explanation, worst first.
- For target {{target}}, show the trust_score trend by started_at from sentinel_hc.meta.test_runs.
- Which test categories have the lowest pass rate across all runs?
- Compare allowed_amount and plan_paid_amount totals by plan_type between sentinel_hc.sandbox.{{target}}_baseline and sentinel_hc.sandbox.{{target}}_candidate.
- Show claim_line_key values that appear more than once in sentinel_hc.sandbox.{{target}}_candidate, with their duplicate count.
