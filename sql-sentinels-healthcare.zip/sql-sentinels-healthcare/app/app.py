"""Databricks App (Streamlit): paste baseline/candidate SQL, run SQL Sentinels, browse history, chat with Genie."""
import os
import sys

import pandas as pd
import streamlit as st

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from databricks.sdk import WorkspaceClient
from sentinel.config import Config
from sentinel.sqlx import WarehouseSQL
from sentinel.run_pipeline import run, build_brain
from sentinel.store import Store

st.set_page_config(page_title="SQL Sentinels - Healthcare Claims", layout="wide", page_icon="🛡️")
cfg, w = Config(), WorkspaceClient()
sql = WarehouseSQL(w, cfg.warehouse_id)
brain = build_brain(cfg, w)

st.title("🛡️ SQL Sentinels - Healthcare Claims")
st.caption("Autonomous testing, continuous trust | Genie + skill-driven prompts + Unity AI Gateway + Lakebase")
t_run, t_hist, t_chat = st.tabs(["Run regression", "History", "Ask Genie"])

with t_run:
    c1, c2 = st.columns(2)
    old_sql = c1.text_area("Baseline SQL (production logic)", height=280)
    new_sql = c2.text_area("Candidate SQL (proposed change)", height=280)
    a, b = st.columns(2)
    target = a.text_input("Output table name", "silver_claim_line")
    key = b.text_input("Key column(s), comma separated", "claim_line_key")
    if st.button("▶ Run SQL Sentinels", type="primary", disabled=not (old_sql and new_sql)):
        with st.status("Running ...", expanded=True) as status:
            res = run(old_sql, new_sql, target, key or None, sql, brain, cfg, w, trigger="app", log=st.write)
            status.update(label="Done", state="complete")
        s = res["score"]
        m = st.columns(4)
        m[0].metric("Trust Score", s["trust_score"]); m[1].metric("Verdict", s["verdict"])
        m[2].metric("Pass rate %", s["pass_rate"]); m[3].metric("Unexplained row change %", s["unexplained_change_pct"])
        st.info(res["analysis"].get("change_summary", ""))
        by = {t["test_id"]: t for t in res["tests"]}
        st.dataframe(pd.DataFrame([{
            "outcome": r["outcome"], "category": by[r["test_id"]]["category"], "source": by[r["test_id"]]["source"],
            "test": by[r["test_id"]]["name"], "severity": by[r["test_id"]]["severity"], "violations": r["violations"],
            "class": r.get("classification"), "why": r.get("ai_explanation")} for r in res["results"]]),
            use_container_width=True)

with t_hist:
    store = Store(cfg, sql, w)
    df = pd.DataFrame(store.recent_runs(), columns=["run_id", "target", "trigger", "trust", "verdict", "pass_rate",
                                                    "coverage", "unexplained_pct", "started_at"])
    st.dataframe(df, use_container_width=True)
    if not df.empty:
        pick = st.selectbox("Run detail", df["run_id"])
        st.dataframe(pd.DataFrame(store.run_results(pick), columns=["category", "name", "severity", "outcome",
                                                                    "violations", "classification", "explanation"]),
                     use_container_width=True)

with t_chat:
    q = st.chat_input("e.g. Why did the claims pipeline fail?")
    if q and brain.genie:
        st.chat_message("user").write(q)
        ans = brain.genie.ask(q, st.session_state.get("conv"))
        st.session_state["conv"] = ans.conversation_id
        with st.chat_message("assistant"):
            st.write(ans.text or ans.description)
            if ans.sql:
                st.code(ans.sql, language="sql")
            if ans.rows:
                st.dataframe(pd.DataFrame(ans.rows, columns=ans.columns))
