"""Writes a small sample dataset to data/*.csv (for upload / inspection).
Usage: python scripts/generate_sample_csv.py [n_claims]"""
import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from sentinel.synth_claims import generate

n = int(sys.argv[1]) if len(sys.argv) > 1 else 1500
out = os.path.join(os.path.dirname(__file__), "..", "data")
os.makedirs(out, exist_ok=True)
for name, df in generate(n_members=300, n_providers=40, n_claims=n).items():
    df.to_csv(os.path.join(out, f"{name}.csv"), index=False)
    print(f"{name:20} {len(df):>7} rows")
