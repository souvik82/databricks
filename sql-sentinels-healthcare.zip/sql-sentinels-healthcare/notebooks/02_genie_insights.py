# Databricks notebook source
# MAGIC %md
# MAGIC # SQL Sentinels - 02 Conversational insights with Genie
# MAGIC The questions come from `skills/genie-followup-questions/SKILL.md`. Genie writes the SQL, runs it on governed tables and answers.

# COMMAND ----------
# MAGIC %pip install -q "databricks-sdk>=0.40.0"
# MAGIC %restart_python

# COMMAND ----------
dbutils.widgets.text("genie_space_id", "", "Genie Space ID")
dbutils.widgets.text("target", "silver_claim_line", "Target table name")
import os, sys
nb = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
ROOT = "/Workspace" + os.path.dirname(os.path.dirname(nb))
sys.path.insert(0, ROOT)
os.environ["SENTINEL_GENIE_SPACE_ID"] = dbutils.widgets.get("genie_space_id")
os.environ["SENTINEL_SKILLS_DIR"] = f"{ROOT}/skills"

import pandas as pd
from databricks.sdk import WorkspaceClient
from sentinel.config import Config
from sentinel.run_pipeline import build_brain

cfg, w = Config(), WorkspaceClient()
brain = build_brain(cfg, w)
target = dbutils.widgets.get("target")
run_id = spark.sql(f"SELECT run_id FROM {cfg.meta('test_runs')} WHERE target = '{target}' ORDER BY started_at DESC LIMIT 1").first()[0]

# COMMAND ----------
questions = brain.reg.render_bullets("genie-followup-questions", "Questions", run_id=run_id, target=target)
conv = None
for q in questions:
    print("\n>>>", q)
    ans = brain.genie.ask(q, conv)
    conv = ans.conversation_id
    if ans.text.strip():
        print(ans.text.strip())
    if ans.sql:
        print("--- Genie SQL ---\n" + ans.sql)
    if ans.rows:
        display(pd.DataFrame(ans.rows, columns=ans.columns))

# COMMAND ----------
# MAGIC %md ## Prompt audit - what was sent, from which skill version

# COMMAND ----------
display(spark.sql(f"SELECT skill_name, skill_version, engine, created_at, left(prompt_text, 160) AS prompt_preview FROM {cfg.meta('prompt_audit')} WHERE run_id = '{run_id}' ORDER BY created_at"))
