# Databricks notebook source
# MAGIC %md
# MAGIC # SQL Sentinels - 00 Setup: DDL, synthetic healthcare claims, production silver/gold
# MAGIC Creates catalog `sentinel_hc` (schemas raw / silver / gold / sandbox / meta), loads synthetic claims data (no PHI),
# MAGIC and materializes the **production** silver + gold tables from the baseline business SQL.
# MAGIC Run on serverless compute or DBR 14.3+ with Unity Catalog.

# COMMAND ----------
dbutils.widgets.text("n_claims", "20000", "Number of claims")
dbutils.widgets.text("n_members", "2000", "Number of members")

import os, re, sys
nb = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
ROOT = "/Workspace" + os.path.dirname(os.path.dirname(nb))     # repo root = parent of notebooks/
sys.path.insert(0, ROOT)
print("Project root:", ROOT)

# COMMAND ----------
# MAGIC %md ## 1. Run the DDL files (`ddl/*.sql`)

# COMMAND ----------
def run_sql_file(path, best_effort=False):
    text = re.sub(r"--[^\n]*", "", open(path).read())
    for stmt in [s.strip() for s in text.split(";") if s.strip()]:
        try:
            spark.sql(stmt)
        except Exception as e:
            if not best_effort:
                raise
            print("  (skipped)", stmt[:90].replace("\n", " "), "->", str(e)[:120])
    print("OK", os.path.basename(path))

for f in ["01_create_schemas.sql", "02_create_raw_tables.sql", "03_create_meta_tables.sql"]:
    run_sql_file(f"{ROOT}/ddl/{f}")

# FK constraints / tags are nice-to-have: do not fail the setup if a workspace policy blocks them
run_sql_file(f"{ROOT}/ddl/04_constraints_and_tags.sql", best_effort=True)

# COMMAND ----------
# MAGIC %md ## 2. Generate and load synthetic claims data

# COMMAND ----------
import pandas as pd
from pyspark.sql.types import StructType, StructField, StringType
from sentinel.synth_claims import generate

CAT = "sentinel_hc"
data = generate(n_members=int(dbutils.widgets.get("n_members")),
                n_providers=200, n_claims=int(dbutils.widgets.get("n_claims")))

def load_table(name, pdf):
    fq = f"{CAT}.raw.{name}"
    target = spark.table(fq).schema
    strs = pdf.apply(lambda c: c.map(lambda v: None if pd.isna(v) else str(v)))
    sdf = spark.createDataFrame(strs.values.tolist(), StructType([StructField(c, StringType(), True) for c in pdf.columns]))
    sdf = sdf.select(*[sdf[f.name].cast(f.dataType).alias(f.name) for f in target.fields])
    spark.sql(f"TRUNCATE TABLE {fq}")
    sdf.write.mode("append").insertInto(fq)
    print(f"{fq:45} {sdf.count():>9,} rows")

for name in ["plan", "member", "member_eligibility", "provider", "ref_cpt", "ref_icd10", "claim_header", "claim_line"]:
    load_table(name, data[name])

# COMMAND ----------
# MAGIC %md ## 3. Materialize PRODUCTION silver and gold from the baseline business SQL

# COMMAND ----------
silver_v1 = open(f"{ROOT}/sql/business/silver_claim_line_v1.sql").read()
gold_sql = open(f"{ROOT}/sql/business/gold_claims_kpi_monthly.sql").read()

spark.sql(f"CREATE OR REPLACE TABLE {CAT}.silver.claim_line_enriched COMMENT 'Production silver: claim-line grain, priced' AS {silver_v1}")
spark.sql(f"CREATE OR REPLACE TABLE {CAT}.gold.claims_kpi_monthly COMMENT 'Production gold: monthly KPIs by plan type' AS "
          + gold_sql.replace("{{silver}}", f"{CAT}.silver.claim_line_enriched"))
display(spark.sql(f"SELECT * FROM {CAT}.gold.claims_kpi_monthly ORDER BY service_month, plan_type LIMIT 20"))

# COMMAND ----------
# MAGIC %md ## 4. Genie Space configuration (comes from a skill file)
# MAGIC Create a Genie Space with the tables and instructions below, then copy its Space ID into notebook 01.

# COMMAND ----------
from sentinel.skills import SkillRegistry
reg = SkillRegistry(f"{ROOT}/skills")
print(reg.render("genie-space-instructions"))
