# Databricks notebook source
# MAGIC %md
# MAGIC # SQL Sentinels - 01 Run autonomous regression test
# MAGIC **Flow:** analyze change -> Genie turns business rules into validation SQL -> execute in sandbox -> classify -> Trust Score.
# MAGIC Every prompt is rendered from `skills/*/SKILL.md` and logged to `sentinel_hc.meta.prompt_audit`.

# COMMAND ----------
# MAGIC %pip install -q sqlglot "databricks-sdk>=0.40.0" "psycopg[binary]"
# MAGIC %restart_python

# COMMAND ----------
dbutils.widgets.text("genie_space_id", "", "Genie Space ID")
dbutils.widgets.text("llm_endpoint", "databricks-claude-sonnet-4", "LLM endpoint (AI Gateway)")
dbutils.widgets.dropdown("scenario", "defects", ["defects", "intended", "no_change"], "Candidate SQL scenario")
dbutils.widgets.dropdown("fail_on_block", "false", ["true", "false"], "Fail notebook when verdict = BLOCK")
dbutils.widgets.text("lakebase_host", "", "Lakebase host (optional)")

import os, sys
nb = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
ROOT = "/Workspace" + os.path.dirname(os.path.dirname(nb))
sys.path.insert(0, ROOT)

os.environ["SENTINEL_GENIE_SPACE_ID"] = dbutils.widgets.get("genie_space_id")
os.environ["SENTINEL_LLM_ENDPOINT"] = dbutils.widgets.get("llm_endpoint")
os.environ["SENTINEL_SKILLS_DIR"] = f"{ROOT}/skills"
if dbutils.widgets.get("lakebase_host"):
    os.environ["PGHOST"] = dbutils.widgets.get("lakebase_host")

from databricks.sdk import WorkspaceClient
from sentinel.config import Config
from sentinel.sqlx import SparkSQL
from sentinel.run_pipeline import run, build_brain

cfg, w, sql = Config(), WorkspaceClient(), SparkSQL(spark)
brain = build_brain(cfg, w)
print("Genie space:", cfg.genie_space_id or "(none -> LLM fallback only)")
print("Skills loaded:", ", ".join(brain.reg.skills))

# COMMAND ----------
# MAGIC %md ## Skill-driven prompts: preview one (this exact text is what Genie receives)

# COMMAND ----------
print(brain.reg.render("rule-to-validation-sql",
      rule="Voided claims (claim_status = 'VOID') must not appear in the output.",
      candidate_table="sentinel_hc.sandbox.silver_claim_line_candidate",
      baseline_table="sentinel_hc.sandbox.silver_claim_line_baseline")[-900:])

# COMMAND ----------
# MAGIC %md ## Run 1 - Silver layer: `silver_claim_line_enriched`

# COMMAND ----------
files = {"defects": "silver_claim_line_v2_defects.sql", "intended": "silver_claim_line_v3_intended.sql",
         "no_change": "silver_claim_line_v1.sql"}
rd = lambda n: open(f"{ROOT}/sql/business/{n}").read()
old_sql, new_sql = rd("silver_claim_line_v1.sql"), rd(files[dbutils.widgets.get("scenario")])

res = run(old_sql, new_sql, "silver_claim_line", "claim_line_key", sql, brain, cfg, w,
          trigger="notebook", prod_fqtn=f"{cfg.catalog}.silver.claim_line_enriched")
print(res["analysis"]["change_summary"])

# COMMAND ----------
displayHTML(f"""<div style='font-family:sans-serif;padding:16px;border-radius:10px;background:#0F2A33;color:#fff;width:520px'>
<div style='font-size:14px;opacity:.7'>TRUST SCORE - silver_claim_line</div>
<div style='font-size:56px;font-weight:700'>{res['score']['trust_score']}</div>
<div style='font-size:18px'>Verdict: <b>{res['score']['verdict']}</b> &nbsp;|&nbsp; pass rate {res['score']['pass_rate']}% &nbsp;|&nbsp; unexplained row change {res['score']['unexplained_change_pct']}%</div></div>""")
display(spark.sql(f"""SELECT outcome, category, source_of_test, name, severity, violations, classification, ai_explanation
  FROM (SELECT r.*, c.source AS source_of_test FROM {cfg.meta('test_results')} r JOIN {cfg.meta('test_cases')} c
        ON r.run_id = c.run_id AND r.test_id = c.test_id) WHERE run_id = '{res['run_id']}'
  ORDER BY CASE outcome WHEN 'fail' THEN 0 WHEN 'error' THEN 1 ELSE 2 END,
           CASE severity WHEN 'critical' THEN 0 WHEN 'high' THEN 1 ELSE 2 END"""))

# COMMAND ----------
# MAGIC %md ## Run 2 - Impact cascade: does the changed silver break gold KPIs?
# MAGIC Baseline gold reads production silver; candidate gold reads the sandbox candidate silver.

# COMMAND ----------
gold = rd("gold_claims_kpi_monthly.sql")
res_gold = run(gold.replace("{{silver}}", f"{cfg.catalog}.silver.claim_line_enriched"),
               gold.replace("{{silver}}", f"{cfg.catalog}.sandbox.silver_claim_line_candidate"),
               "gold_claims_kpi_monthly", "service_month,plan_type", sql, brain, cfg, w, trigger="notebook-cascade",
               prod_fqtn=f"{cfg.catalog}.gold.claims_kpi_monthly")
print(res_gold["score"])

# COMMAND ----------
# MAGIC %md ## CI/CD gate

# COMMAND ----------
worst = min(res["score"]["trust_score"], res_gold["score"]["trust_score"])
verdict = "SAFE" if worst >= 90 else "REVIEW" if worst >= 70 else "BLOCK"
print("Release verdict:", verdict, "| worst Trust Score:", worst)
if verdict == "BLOCK" and dbutils.widgets.get("fail_on_block") == "true":
    raise Exception(f"SQL Sentinels BLOCK - Trust Score {worst}")
dbutils.notebook.exit(verdict)
