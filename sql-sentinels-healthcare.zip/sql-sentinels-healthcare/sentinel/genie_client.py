"""Genie Conversation API wrapper, LLM (Unity AI Gateway endpoint) helper, JSON extraction."""
import json
import re
from dataclasses import dataclass, field


@dataclass
class GenieAnswer:
    text: str = ""
    sql: str | None = None
    description: str | None = None
    columns: list = field(default_factory=list)
    rows: list = field(default_factory=list)
    conversation_id: str | None = None


class GenieAgent:
    def __init__(self, w, space_id: str):
        self.w, self.space_id = w, space_id

    def ask(self, prompt: str, conversation_id: str | None = None) -> GenieAnswer:
        g = self.w.genie
        if conversation_id:
            msg = g.create_message_and_wait(self.space_id, conversation_id, prompt)
        else:
            msg = g.start_conversation_and_wait(self.space_id, prompt)
        ans = GenieAnswer(conversation_id=msg.conversation_id)
        msg_id = getattr(msg, "message_id", None) or msg.id
        for att in msg.attachments or []:
            if att.text:
                ans.text += (att.text.content or "") + "\n"
            if att.query:
                ans.sql, ans.description = att.query.query, att.query.description
                try:
                    res = g.get_message_attachment_query_result(
                        self.space_id, msg.conversation_id, msg_id, att.attachment_id)
                    sr = res.statement_response
                    ans.columns = [c.name for c in sr.manifest.schema.columns]
                    ans.rows = sr.result.data_array or []
                except Exception:
                    pass
        return ans


class LLM:
    def __init__(self, w, endpoint: str):
        self.client = w.serving_endpoints.get_open_ai_client()
        self.endpoint = endpoint

    def text(self, prompt: str, system="You are a precise assistant.") -> str:
        r = self.client.chat.completions.create(
            model=self.endpoint, temperature=0.1, max_tokens=3000,
            messages=[{"role": "system", "content": system}, {"role": "user", "content": prompt}])
        return r.choices[0].message.content

    def json(self, prompt: str):
        return extract_json(self.text(prompt, "Return ONLY valid JSON. No prose, no code fences."))


def extract_json(text: str):
    if not text:
        raise ValueError("empty response")
    text = re.sub(r"```(?:json|sql)?", "", text).strip()
    starts = [i for i in (text.find("{"), text.find("[")) if i != -1]
    if not starts:
        raise ValueError("no JSON found")
    return json.loads(text[min(starts): max(text.rfind("}"), text.rfind("]")) + 1])


def extract_sql(text: str) -> str | None:
    m = re.search(r"```(?:sql)?\s*(.*?)```", text or "", re.S)
    return (m.group(1) if m else text or "").strip().rstrip(";") or None


class Brain:
    """Routes a skill to its engine (Genie first, LLM fallback) and records every prompt for audit."""
    def __init__(self, registry, genie=None, llm=None):
        self.reg, self.genie, self.llm = registry, genie, llm

    def _engines(self, skill):
        order = [skill.engine, skill.fallback_engine]
        return [e for e in order if (e == "genie" and self.genie) or (e == "llm" and self.llm)]

    def json(self, name, **v):
        s = self.reg.get(name)
        prompt = self.reg.render(name, **v)
        last = None
        for eng in self._engines(s):
            try:
                self.reg.record(name, prompt, eng)
                out = extract_json(self.genie.ask(prompt).text) if eng == "genie" else self.llm.json(prompt)
                return out, eng
            except Exception as e:
                last = e
        raise RuntimeError(f"skill {name}: no engine produced JSON ({last})")

    def sql(self, name, **v):
        s = self.reg.get(name)
        prompt = self.reg.render(name, **v)
        for eng in self._engines(s):
            try:
                self.reg.record(name, prompt, eng)
                if eng == "genie":
                    ans = self.genie.ask(prompt)
                    sql = ans.sql or extract_sql(ans.text)
                else:
                    sql = extract_sql(self.llm.text(prompt + "\nReturn ONLY the SQL."))
                if sql:
                    return sql, eng
            except Exception:
                continue
        return None, None

    def text(self, name, conversation_id=None, **v):
        prompt = self.reg.render(name, **v)
        self.reg.record(name, prompt, "genie")
        return self.genie.ask(prompt, conversation_id)
