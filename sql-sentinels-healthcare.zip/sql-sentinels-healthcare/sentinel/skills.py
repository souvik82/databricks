"""Skill library: every prompt Genie or the LLM receives is rendered from skills/<name>/SKILL.md.
Features: front-matter metadata, {{> include}} of other skills, {{variable}} substitution with
required-input validation, rule-catalog extraction, and an audit trail of every rendered prompt."""
import hashlib
import os
import re
from dataclasses import dataclass, field

_INCLUDE = re.compile(r"\{\{\s*>\s*([\w\-]+)\s*\}\}")
_VAR = re.compile(r"\{\{\s*([A-Za-z_]\w*)\s*\}\}")


@dataclass
class Skill:
    name: str
    description: str
    engine: str            # genie | llm | none
    fallback_engine: str
    inputs: list
    output: str
    body: str
    version: str           # sha of the file content, stored in the prompt audit


def _parse(path: str) -> Skill:
    raw = open(path, encoding="utf-8").read()
    m = re.match(r"^---\n(.*?)\n---\n(.*)$", raw, re.S)
    if not m:
        raise ValueError(f"{path}: missing front matter")
    meta = {}
    for line in m.group(1).splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            meta[k.strip()] = v.strip()
    inputs = [x.strip() for x in meta.get("inputs", "[]").strip("[]").split(",") if x.strip()]
    return Skill(meta["name"], meta.get("description", ""), meta.get("engine", "none"),
                 meta.get("fallback_engine", "none"), inputs, meta.get("output", "text"),
                 m.group(2).strip(), hashlib.sha256(raw.encode()).hexdigest()[:10])


class SkillRegistry:
    def __init__(self, root: str):
        self.skills, self.audit = {}, []
        for d in sorted(os.listdir(root)):
            p = os.path.join(root, d, "SKILL.md")
            if os.path.isfile(p):
                s = _parse(p)
                self.skills[s.name] = s

    def get(self, name: str) -> Skill:
        return self.skills[name]

    def _expand(self, body: str, depth=0) -> str:
        if depth > 5:
            raise RecursionError("skill include depth exceeded")
        return _INCLUDE.sub(lambda m: self._expand(self.get(m.group(1)).body, depth + 1), body)

    def render(self, name: str, **variables) -> str:
        s = self.get(name)
        missing = [i for i in s.inputs if i not in variables]
        if missing:
            raise KeyError(f"skill '{name}' missing inputs: {missing}")
        text = self._expand(s.body)
        text = _VAR.sub(lambda m: str(variables[m.group(1)]) if m.group(1) in variables else m.group(0), text)
        left = _VAR.findall(text)
        if left:
            raise KeyError(f"skill '{name}' has unresolved placeholders: {left}")
        return text

    def record(self, name: str, prompt: str, engine: str):
        self.audit.append({"skill_name": name, "skill_version": self.get(name).version,
                           "engine": engine, "prompt_text": prompt})

    def bullets(self, name: str, section: str) -> list:
        """Bullet items under a '## <section>' heading of a skill (e.g. the rule catalog)."""
        body, out, on = self.get(name).body, [], False
        for line in body.splitlines():
            if line.startswith("## "):
                on = line[3:].strip().lower() == section.lower()
            elif on and line.startswith("- "):
                out.append(line[2:].strip())
        return out

    def render_bullets(self, name: str, section: str, **variables) -> list:
        """Bullets of a section with {{variables}} filled in (used for Genie follow-up questions)."""
        out = []
        for b in self.bullets(name, section):
            out.append(_VAR.sub(lambda m: str(variables.get(m.group(1), m.group(0))), b))
            self.record(name, out[-1], "genie")
        return out
