"""Persistence: Delta tables in Unity Catalog (Genie + dashboards read them) + optional Lakebase mirror."""
import json


class Store:
    def __init__(self, cfg, sql, w=None):
        self.cfg, self.sql, self.w = cfg, sql, w
        self.pg = self._connect_pg()

    def _connect_pg(self):
        if not self.cfg.pg_host or self.w is None:
            return None
        try:
            import psycopg
            conn = psycopg.connect(host=self.cfg.pg_host, dbname=self.cfg.pg_db, sslmode="require", autocommit=True,
                                   user=self.cfg.pg_user or self.w.current_user.me().user_name,
                                   password=self.w.config.oauth_token().access_token)
            conn.execute("""CREATE TABLE IF NOT EXISTS sentinel_runs(run_id text PRIMARY KEY, target text, trigger text,
                trust_score int, verdict text, change_summary text, started_at timestamptz DEFAULT now())""")
            conn.execute("""CREATE TABLE IF NOT EXISTS sentinel_results(run_id text, test_id text, category text,
                name text, outcome text, violations bigint, classification text, ai_explanation text)""")
            return conn
        except Exception as e:
            print(f"[lakebase] disabled: {e}")
            return None

    def save(self, run_id, target, trigger, analysis, tests, results, score, audit):
        m, by_id, s = self.cfg.meta, {t["test_id"]: t for t in tests}, self.sql.insert_many
        s(m("change_analysis"), ["run_id", "target", "engine", "change_summary", "risk_level", "analysis_json", "created_at"],
          ["STRING"] * 6 + ["NOW"],
          [[run_id, target, analysis.get("engine"), analysis.get("change_summary"), analysis.get("risk_level"),
            json.dumps(analysis, default=str), None]])
        s(m("test_cases"), ["run_id", "test_id", "category", "name", "sql_text", "severity", "source", "rationale", "sample_sql"],
          ["STRING"] * 9,
          [[run_id, t["test_id"], t["category"], t["name"], t["sql"], t["severity"], t["source"], t["rationale"],
            t.get("sample_sql")] for t in tests])
        s(m("test_results"), ["run_id", "test_id", "category", "name", "severity", "outcome", "violations",
                              "classification", "ai_explanation", "sample_json", "duration_ms", "error"],
          ["STRING"] * 6 + ["BIGINT"] + ["STRING"] * 3 + ["INT", "STRING"],
          [[run_id, r["test_id"], by_id[r["test_id"]]["category"], by_id[r["test_id"]]["name"],
            by_id[r["test_id"]]["severity"], r["outcome"], r["violations"], r.get("classification"),
            r.get("ai_explanation"), json.dumps(r.get("sample"), default=str), r["duration_ms"], r.get("error")]
           for r in results])
        s(m("test_runs"), ["run_id", "target", "trigger", "started_at", "trust_score", "verdict", "pass_rate",
                           "coverage", "unexplained_pct"],
          ["STRING", "STRING", "STRING", "NOW", "INT", "STRING", "DOUBLE", "DOUBLE", "DOUBLE"],
          [[run_id, target, trigger, None, score["trust_score"], score["verdict"], score["pass_rate"],
            score["coverage"], score["unexplained_change_pct"]]])
        if audit:
            s(m("prompt_audit"), ["run_id", "skill_name", "skill_version", "engine", "prompt_text", "created_at"],
              ["STRING"] * 5 + ["NOW"],
              [[run_id, a["skill_name"], a["skill_version"], a["engine"], a["prompt_text"], None] for a in audit])
        if self.pg:
            self.pg.execute("INSERT INTO sentinel_runs(run_id,target,trigger,trust_score,verdict,change_summary) "
                            "VALUES (%s,%s,%s,%s,%s,%s)", (run_id, target, trigger, score["trust_score"],
                                                           score["verdict"], analysis.get("change_summary")))
            for r in results:
                t = by_id[r["test_id"]]
                self.pg.execute("INSERT INTO sentinel_results VALUES (%s,%s,%s,%s,%s,%s,%s,%s)",
                                (run_id, r["test_id"], t["category"], t["name"], r["outcome"], r["violations"],
                                 r.get("classification"), r.get("ai_explanation")))

    def recent_runs(self, n=20):
        return self.sql.run(f"SELECT run_id,target,trigger,trust_score,verdict,pass_rate,coverage,unexplained_pct,"
                            f"started_at FROM {self.cfg.meta('test_runs')} ORDER BY started_at DESC LIMIT {int(n)}")

    def run_results(self, run_id):
        return self.sql.run("SELECT category,name,severity,outcome,violations,classification,ai_explanation "
                            f"FROM {self.cfg.meta('test_results')} WHERE run_id=:r", {"r": run_id})
