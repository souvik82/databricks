"""Stage 3: build baseline/candidate in the sandbox schema, run every test in parallel."""
import time
from concurrent.futures import ThreadPoolExecutor


def _cols(cfg, sql, table_name):
    return [(r[0], r[1]) for r in sql.run(
        f"SELECT column_name, data_type FROM {cfg.catalog}.information_schema.columns "
        f"WHERE table_schema='{cfg.sandbox_schema}' AND table_name='{table_name}' ORDER BY ordinal_position")]


def build_sandbox(cfg, sql, target, old_sql, new_sql):
    bn, cn = f"{target}_baseline", f"{target}_candidate"
    base, cand = cfg.sandbox(bn), cfg.sandbox(cn)
    sql.run(f"CREATE SCHEMA IF NOT EXISTS {cfg.catalog}.{cfg.sandbox_schema}")
    sql.run(f"CREATE OR REPLACE TABLE {base} AS {old_sql}")
    sql.run(f"CREATE OR REPLACE TABLE {cand} AS {new_sql}")
    counts = {"baseline": int(sql.run(f"SELECT COUNT(*) FROM {base}")[0][0]),
              "candidate": int(sql.run(f"SELECT COUNT(*) FROM {cand}")[0][0])}
    return base, cand, bn, cn, _cols(cfg, sql, bn), _cols(cfg, sql, cn), counts


def _run_one(sql, t):
    t0 = time.time()
    res = {"test_id": t["test_id"], "outcome": "error", "violations": None, "sample": None, "error": None}
    try:
        rows = sql.run(t["sql"])
        v = int(float(rows[0][0])) if rows and rows[0][0] is not None else 0
        res["violations"] = v
        res["outcome"] = "pass" if v <= t.get("tolerance", 0) else "fail"
        if res["outcome"] == "fail" and t.get("sample_sql"):
            try:
                res["sample"] = [[str(x) for x in r] for r in sql.run(t["sample_sql"])]
            except Exception:
                pass
    except Exception as e:
        res["error"] = str(e)[:500]
    res["duration_ms"] = int((time.time() - t0) * 1000)
    return res


def execute(sql, tests, workers=4):
    with ThreadPoolExecutor(max_workers=workers) as ex:
        return list(ex.map(lambda t: _run_one(sql, t), tests))
