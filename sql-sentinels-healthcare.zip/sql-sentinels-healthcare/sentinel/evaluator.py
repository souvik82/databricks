"""Stage 4: classify failures (skill: classify-failures) and compute the Trust Score."""
import json

WEIGHT = {"critical": 25, "high": 15, "medium": 8, "low": 3}
ALL_CATEGORIES = {"structural", "volume", "data_quality", "business_logic", "regression_diff", "edge_case"}


def classify(brain, analysis, tests, results):
    by_id = {t["test_id"]: t for t in tests}
    failed = [{"test_id": r["test_id"], "name": by_id[r["test_id"]]["name"],
               "category": by_id[r["test_id"]]["category"], "violations": r["violations"], "sample": r.get("sample")}
              for r in results if r["outcome"] == "fail"]
    labels = {}
    if failed:
        try:
            items, _ = brain.json("classify-failures", change_summary=analysis.get("change_summary"),
                                  rules=analysis.get("business_rules"), failed=json.dumps(failed, default=str)[:12000])
            labels = {x["test_id"]: (x.get("classification", "regression"), x.get("explanation", "")) for x in items}
        except Exception:
            pass
    for r in results:
        default = ("regression", "") if r["outcome"] in ("fail", "error") else (None, "")
        r["classification"], r["ai_explanation"] = labels.get(r["test_id"], default)
    return results


def trust_score(tests, results, counts):
    by_id = {t["test_id"]: t for t in tests}
    penalty = 0.0
    for r in results:
        if r["outcome"] in ("fail", "error"):
            w = WEIGHT.get(by_id[r["test_id"]]["severity"], 8)
            penalty += w * (0.2 if r.get("classification") == "expected_change" else 1.0)
    pass_rate = sum(r["outcome"] == "pass" for r in results) / max(len(results), 1)
    coverage = len({t["category"] for t in tests} & ALL_CATEGORIES) / len(ALL_CATEGORIES)
    unexplained = abs(counts["candidate"] - counts["baseline"]) / max(counts["baseline"], 1) * 100
    score = int(max(0, min(100, round(100 - penalty - (1 - coverage) * 10 - min(15, unexplained)))))
    return {"trust_score": score, "verdict": "SAFE" if score >= 90 else "REVIEW" if score >= 70 else "BLOCK",
            "pass_rate": round(pass_rate * 100, 1), "coverage": round(coverage * 100, 1),
            "unexplained_change_pct": round(unexplained, 2)}
