"""Synthetic healthcare-claims generator (100% fake data, no PHI). Deterministic via seed.
Produces pandas DataFrames whose columns match ddl/02_create_raw_tables.sql exactly."""
import numpy as np
import pandas as pd

PLANS = [  # plan_id, name, type, deductible, copay_pcp, copay_specialist, coinsurance, oop_max
    ("P-HMO-100", "Sentinel HMO Gold", "HMO", 500, 20, 40, 0.10, 4000),
    ("P-PPO-200", "Sentinel PPO Silver", "PPO", 1500, 30, 60, 0.20, 6500),
    ("P-HDHP-300", "Sentinel HDHP Bronze", "HDHP", 3000, 0, 0, 0.30, 8000),
    ("P-MA-400", "Sentinel Medicare Advantage", "MEDICARE_ADV", 0, 10, 35, 0.15, 5500),
    ("P-EPO-500", "Sentinel EPO Plus", "EPO", 1000, 25, 50, 0.25, 7000),
]
CPT = [  # code, description (generic wording), category, contracted fee
    ("99202", "Office visit new patient - low", "E&M", 95), ("99203", "Office visit new patient - moderate", "E&M", 140),
    ("99213", "Office visit established - low", "E&M", 105), ("99214", "Office visit established - moderate", "E&M", 155),
    ("99215", "Office visit established - high", "E&M", 215), ("99283", "Emergency visit - moderate", "E&M", 260),
    ("80053", "Comprehensive metabolic panel", "LAB", 22), ("85025", "Complete blood count", "LAB", 14),
    ("83036", "Hemoglobin A1c", "LAB", 18), ("80061", "Lipid panel", "LAB", 20), ("81001", "Urinalysis", "LAB", 8),
    ("71046", "Chest X-ray 2 views", "RADIOLOGY", 62), ("72148", "MRI lumbar spine", "RADIOLOGY", 480),
    ("73721", "MRI knee", "RADIOLOGY", 455), ("77067", "Screening mammography", "RADIOLOGY", 135),
    ("74177", "CT abdomen/pelvis with contrast", "RADIOLOGY", 520),
    ("29881", "Knee arthroscopy", "SURGERY", 1850), ("47562", "Laparoscopic cholecystectomy", "SURGERY", 3100),
    ("45378", "Colonoscopy diagnostic", "SURGERY", 880), ("66984", "Cataract surgery with lens", "SURGERY", 1650),
    ("93000", "Electrocardiogram", "CARDIO", 28), ("93306", "Echocardiogram complete", "CARDIO", 240),
    ("97110", "Therapeutic exercise 15 min", "THERAPY", 45), ("90837", "Psychotherapy 60 min", "THERAPY", 150),
]
ICD = [
    ("E11.9", "Type 2 diabetes without complications", True), ("I10", "Essential hypertension", True),
    ("J45.909", "Unspecified asthma", True), ("E78.5", "Hyperlipidemia unspecified", True),
    ("F32.9", "Major depressive disorder single episode", True), ("N18.3", "Chronic kidney disease stage 3", True),
    ("J06.9", "Acute upper respiratory infection", False), ("M54.50", "Low back pain unspecified", False),
    ("S83.512A", "Sprain of ACL right knee", False), ("K80.20", "Calculus of gallbladder", False),
    ("R07.9", "Chest pain unspecified", False), ("Z00.00", "General adult medical exam", False),
    ("H25.9", "Unspecified age-related cataract", False), ("K63.5", "Polyp of colon", False),
]
SPECIALTIES = ["PRIMARY CARE", "PRIMARY CARE", "CARDIOLOGY", "ORTHOPEDICS", "RADIOLOGY", "GENERAL SURGERY",
               "ENDOCRINOLOGY", "BEHAVIORAL HEALTH", "EMERGENCY MEDICINE", "OPHTHALMOLOGY"]
STATES = ["CA", "TX", "NY", "FL", "IL", "WA", "MA", "GA"]


def _fmt(ts):
    return pd.DatetimeIndex(ts).strftime("%Y-%m-%d")


def generate(n_members=2000, n_providers=200, n_claims=20000, seed=42) -> dict:
    rng = np.random.default_rng(seed)
    plan = pd.DataFrame(PLANS, columns=["plan_id", "plan_name", "plan_type", "deductible", "copay_pcp",
                                        "copay_specialist", "coinsurance_pct", "oop_max"])
    cpt = pd.DataFrame(CPT, columns=["cpt_code", "description", "cpt_category", "fee_schedule_amount"])
    icd = pd.DataFrame(ICD, columns=["icd10_code", "description", "chronic_flag"])

    mid = [f"M{i:06d}" for i in range(1, n_members + 1)]
    birth = pd.Timestamp("1940-01-01") + pd.to_timedelta(rng.integers(0, 29000, n_members), "D")
    member = pd.DataFrame({
        "member_id": mid, "gender": rng.choice(["F", "M"], n_members), "birth_date": _fmt(birth),
        "state": rng.choice(STATES, n_members), "zip3": rng.integers(100, 999, n_members).astype(str)})

    # eligibility: 78% one span, 15% plan change on 2024-07-01 (two spans), 7% late-start coverage
    kind = rng.choice(["single", "change", "late"], n_members, p=[0.78, 0.15, 0.07])
    pl = plan["plan_id"].to_numpy()
    elig = []
    for m, k in zip(mid, kind):
        p1 = str(rng.choice(pl))
        if k == "single":
            elig.append((m, p1, "2024-01-01", "2024-12-31"))
        elif k == "change":
            p2 = str(rng.choice([p for p in pl if p != p1]))
            elig += [(m, p1, "2024-01-01", "2024-06-30"), (m, p2, "2024-07-01", "2024-12-31")]
        else:
            start = (pd.Timestamp("2024-03-01") + pd.Timedelta(days=int(rng.integers(0, 180)))).strftime("%Y-%m-%d")
            elig.append((m, p1, start, "2024-12-31"))
    elig = pd.DataFrame(elig, columns=["member_id", "plan_id", "eff_date", "term_date"])

    pid = [f"PR{i:05d}" for i in range(1, n_providers + 1)]
    provider = pd.DataFrame({
        "provider_id": pid, "npi": [str(1000000000 + int(x)) for x in rng.integers(0, 899999999, n_providers)],
        "provider_name": [f"Synthetic Provider Group {i}" for i in range(1, n_providers + 1)],
        "specialty": rng.choice(SPECIALTIES, n_providers),
        "network_status": rng.choice(["IN", "OUT"], n_providers, p=[0.8, 0.2]),
        "state": rng.choice(STATES, n_providers)})

    cid = np.array([f"CLM{i:08d}" for i in range(1, n_claims + 1)])
    ctype = rng.choice(["PROF", "INST"], n_claims, p=[0.85, 0.15])
    sfrom = pd.Timestamp("2024-01-01") + pd.to_timedelta(rng.integers(0, 366, n_claims), "D")
    sto = sfrom + pd.to_timedelta(np.where(ctype == "INST", rng.integers(0, 6, n_claims), 0), "D")
    status = rng.choice(["PAID", "DENIED", "PENDING", "VOID"], n_claims, p=[0.83, 0.07, 0.04, 0.06])
    header = pd.DataFrame({
        "claim_id": cid, "claim_version": 1, "member_id": rng.choice(mid, n_claims),
        "provider_id": rng.choice(pid, n_claims), "claim_type": ctype,
        "service_from_date": _fmt(sfrom), "service_to_date": _fmt(sto),
        "received_date": _fmt(sto + pd.to_timedelta(rng.integers(1, 31, n_claims), "D")),
        "claim_status": status, "primary_dx": rng.choice(icd["icd10_code"], n_claims)})

    n_lines = np.clip(rng.geometric(0.45, n_claims), 1, 5)
    fee = dict(zip(cpt.cpt_code, cpt.fee_schedule_amount))
    cat = dict(zip(cpt.cpt_code, cpt.cpt_category))
    inst_codes = cpt[cpt.cpt_category.isin(["SURGERY", "RADIOLOGY", "CARDIO"])]["cpt_code"].to_numpy()
    prof_codes = cpt[cpt.cpt_category.isin(["E&M", "LAB", "THERAPY", "RADIOLOGY"])]["cpt_code"].to_numpy()
    rows = []
    for i in range(n_claims):
        pool = inst_codes if ctype[i] == "INST" else prof_codes
        for ln in range(1, int(n_lines[i]) + 1):
            c = str(rng.choice(pool))
            u = 1 if cat[c] in ("E&M", "SURGERY") else int(rng.integers(1, 4))
            billed = round(fee[c] * u * float(rng.uniform(0.8, 2.4)), 2)
            reason = str(rng.choice(["CO-50", "CO-97", "PR-1", "CO-18"])) if status[i] == "DENIED" else None
            rows.append((cid[i], 1, ln, c, u, billed, str(rng.choice(["11", "22", "21", "81"])), reason))
    line = pd.DataFrame(rows, columns=["claim_id", "claim_version", "line_number", "cpt_code", "units",
                                       "billed_amount", "place_of_service", "denial_reason_code"])

    # adjustments: 8% of claims get version 2 (re-adjudicated, billed amounts revised)
    adj_ids = rng.choice(cid, int(n_claims * 0.08), replace=False)
    h2 = header[header.claim_id.isin(adj_ids)].copy()
    h2["claim_version"] = 2
    h2["received_date"] = _fmt(pd.to_datetime(h2["received_date"]) + pd.Timedelta(days=20))
    l2 = line[line.claim_id.isin(adj_ids)].copy()
    l2["claim_version"] = 2
    l2["billed_amount"] = (l2["billed_amount"] * rng.uniform(0.85, 1.15, len(l2))).round(2)
    header = pd.concat([header, h2], ignore_index=True)
    line = pd.concat([line, l2], ignore_index=True)

    return {"plan": plan, "member": member, "member_eligibility": elig, "provider": provider,
            "ref_cpt": cpt, "ref_icd10": icd, "claim_header": header, "claim_line": line}
