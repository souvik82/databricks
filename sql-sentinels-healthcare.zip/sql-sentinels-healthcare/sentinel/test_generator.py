"""Stage 2: generate tests. Every test is a SELECT returning one row with integer column `violations`.
  builtin : structure, volume, key, row-level diff, aggregate drift (deterministic)
  genie   : one validation query per business rule (skill: rule-to-validation-sql)
  llm     : edge cases (skill: edge-case-tests)"""
import re
import uuid

NUMERIC = {"INT", "BIGINT", "SMALLINT", "TINYINT", "LONG", "DOUBLE", "FLOAT", "DECIMAL", "NUMERIC", "INTEGER",
           "HUGEINT", "REAL"}
FORBIDDEN = re.compile(r"\b(insert|update|delete|drop|alter|create|truncate|merge|grant|revoke|call)\b", re.I)


def is_safe(sql) -> bool:
    if not sql:
        return False
    s = sql.strip().rstrip(";")
    return s.lower().startswith(("select", "with")) and ";" not in s and not FORBIDDEN.search(s)


def _t(cat, name, sql, sev, rationale, src="builtin", sample=None, tol=0):
    return {"test_id": uuid.uuid4().hex[:8], "category": cat, "name": name, "sql": sql, "severity": sev,
            "rationale": rationale, "source": src, "sample_sql": sample, "tolerance": tol}


def _base_type(t: str) -> str:
    return t.upper().split("(")[0].strip()


def builtin_tests(cfg, base, cand, base_name, cand_name, base_cols, cand_cols, key):
    info = f"{cfg.catalog}.information_schema.columns"
    sch = cfg.sandbox_schema

    def colq(tn):
        return f"SELECT column_name, data_type FROM {info} WHERE table_schema='{sch}' AND table_name='{tn}'"

    common = [c for c, _ in cand_cols if c in {b for b, _ in base_cols}]
    cl = ", ".join(common)
    keys = [k.strip() for k in (key or "").split(",") if k.strip()]
    tests = [
        _t("structural", "Schema drift (columns / types)",
           f"SELECT COUNT(*) AS violations FROM (({colq(base_name)} EXCEPT {colq(cand_name)}) "
           f"UNION ALL ({colq(cand_name)} EXCEPT {colq(base_name)}))", "high",
           "Output columns or data types differ from the baseline."),
        _t("volume", f"Row count within {cfg.row_count_tolerance:.0%} of baseline",
           f"SELECT CASE WHEN ABS(c.n-b.n) > {cfg.row_count_tolerance}*GREATEST(b.n,1) THEN ABS(c.n-b.n) ELSE 0 END "
           f"AS violations FROM (SELECT COUNT(*) n FROM {cand}) c, (SELECT COUNT(*) n FROM {base}) b", "high",
           "Unexpected row-count change usually means join fan-out, a dropped filter or lost rows."),
        _t("regression_diff", "Baseline rows missing in candidate",
           f"SELECT COUNT(*) AS violations FROM (SELECT {cl} FROM {base} EXCEPT ALL SELECT {cl} FROM {cand}) x",
           "medium", "Baseline rows (common columns) not reproduced by the new logic.",
           sample=f"SELECT {cl} FROM {base} EXCEPT ALL SELECT {cl} FROM {cand} LIMIT 5"),
        _t("regression_diff", "New rows in candidate vs baseline",
           f"SELECT COUNT(*) AS violations FROM (SELECT {cl} FROM {cand} EXCEPT ALL SELECT {cl} FROM {base}) x",
           "medium", "Candidate rows (common columns) that do not exist in the baseline.",
           sample=f"SELECT {cl} FROM {cand} EXCEPT ALL SELECT {cl} FROM {base} LIMIT 5"),
    ]
    if keys:
        kl = ", ".join(keys)
        nulls = " OR ".join(f"{k} IS NULL" for k in keys)
        tests += [
            _t("data_quality", f"Unique key ({kl})",
               f"SELECT (SELECT COUNT(*) FROM {cand}) - (SELECT COUNT(*) FROM (SELECT DISTINCT {kl} FROM {cand}) d) "
               f"AS violations", "critical", "Duplicate keys indicate join fan-out.",
               sample=f"SELECT {kl}, COUNT(*) AS c FROM {cand} GROUP BY {kl} HAVING COUNT(*) > 1 LIMIT 5"),
            _t("data_quality", f"No NULL key ({kl})",
               f"SELECT COUNT(*) AS violations FROM {cand} WHERE {nulls}", "critical", "Keys must never be NULL."),
        ]
    base_types = dict(base_cols)
    nums = [c for c, t in cand_cols if _base_type(t) in NUMERIC and c in base_types and c not in keys
            and not c.endswith(("_number", "_id", "_key"))]
    for c in nums[:6]:
        tests.append(_t("regression_diff", f"Aggregate drift SUM({c}) < 1%",
            f"SELECT CASE WHEN ABS(c.v-b.v) > 0.01*ABS(b.v) THEN 1 ELSE 0 END AS violations FROM "
            f"(SELECT COALESCE(SUM({c}),0) v FROM {cand}) c, (SELECT COALESCE(SUM({c}),0) v FROM {base}) b",
            "medium", f"Total of {c} moved by more than 1% versus the baseline."))
    return tests


def rule_tests(cfg, brain, rules, base, cand):
    out = []
    for rule in rules[: cfg.max_genie_rules]:
        sql, eng = brain.sql("rule-to-validation-sql", rule=rule, candidate_table=cand, baseline_table=base)
        if is_safe(sql):
            out.append(_t("business_logic", rule[:110], sql.strip().rstrip(";"), "high",
                          f"Validation of rule (via {eng}): {rule}", src=eng))
    return out


def edge_tests(brain, analysis, base, cand, cols):
    try:
        items, _ = brain.json("edge-case-tests", candidate_table=cand, baseline_table=base,
                              columns=[c for c, _ in cols], rules=analysis.get("business_rules"),
                              risky_changes=analysis.get("risky_changes"))
    except Exception:
        return []
    return [_t("edge_case", str(i.get("name", "edge case"))[:110], i["sql"].strip().rstrip(";"),
               i.get("severity", "medium"), i.get("rationale", ""), src="llm")
            for i in items if is_safe(i.get("sql"))]


def generate(cfg, brain, analysis, base, cand, base_name, cand_name, base_cols, cand_cols, key):
    tests = builtin_tests(cfg, base, cand, base_name, cand_name, base_cols, cand_cols, key)
    tests += rule_tests(cfg, brain, analysis.get("business_rules", []), base, cand)
    tests += edge_tests(brain, analysis, base, cand, cand_cols)
    return tests
