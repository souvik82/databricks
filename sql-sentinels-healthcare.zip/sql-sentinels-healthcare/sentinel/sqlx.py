"""SQL backends with one interface:  run(statement, params) -> list[list]  (named params as :name)
 - SparkSQL      : inside a Databricks notebook / job (spark.sql)
 - WarehouseSQL  : outside Databricks (Statement Execution API on a SQL warehouse)
 - insert_many() : batched, typed INSERT used by the store (works on both)"""
import time


class _Base:
    def insert_many(self, table: str, columns: list, types: list, rows: list, chunk=40):
        """types: SQL type per column, or 'NOW' to stamp current_timestamp()."""
        for i in range(0, len(rows), chunk):
            params, values = {}, []
            for r, row in enumerate(rows[i:i + chunk]):
                cells = []
                for c, (t, v) in enumerate(zip(types, row)):
                    if t == "NOW":
                        cells.append("current_timestamp()")
                    else:
                        k = f"p{r}_{c}"
                        params[k] = None if v is None else str(v)
                        cells.append(f"CAST(:{k} AS {t})")
                values.append("(" + ",".join(cells) + ")")
            self.run(f"INSERT INTO {table} ({','.join(columns)}) VALUES " + ",".join(values), params)


class SparkSQL(_Base):
    def __init__(self, spark):
        self.spark = spark

    def run(self, statement, params=None):
        df = self.spark.sql(statement, args=params or None)
        return [list(r) for r in df.collect()] if df.columns else []


class WarehouseSQL(_Base):
    def __init__(self, w, warehouse_id):
        from databricks.sdk.service.sql import StatementState
        self.w, self.warehouse_id, self._S = w, warehouse_id, StatementState

    def run(self, statement, params=None):
        from databricks.sdk.service.sql import StatementParameterListItem
        plist = [StatementParameterListItem(name=k, value=None if v is None else str(v), type="STRING")
                 for k, v in (params or {}).items()] or None
        r = self.w.statement_execution.execute_statement(
            statement=statement, warehouse_id=self.warehouse_id, parameters=plist, wait_timeout="50s")
        while r.status.state in (self._S.PENDING, self._S.RUNNING):
            time.sleep(2)
            r = self.w.statement_execution.get_statement(r.statement_id)
        if r.status.state != self._S.SUCCEEDED:
            raise RuntimeError(r.status.error.message if r.status.error else str(r.status.state))
        return r.result.data_array if r.result and r.result.data_array else []


def get_sql(w=None, warehouse_id=None, spark=None):
    if spark is not None:
        return SparkSQL(spark)
    return WarehouseSQL(w, warehouse_id)
