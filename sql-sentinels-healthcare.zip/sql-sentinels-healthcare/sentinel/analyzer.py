"""Stage 1: sqlglot structure + UC lineage + skill-driven business-logic extraction (Genie -> LLM fallback)."""
import sqlglot
from sqlglot import exp


def facts(sql: str) -> dict:
    t = sqlglot.parse_one(sql, read="databricks")
    joins = []
    for j in t.find_all(exp.Join):
        on = j.args.get("on")
        joins.append({"kind": ((j.side or "") + " " + (j.kind or "")).strip().upper() or "INNER",
                      "table": j.this.sql(dialect="databricks"), "on": on.sql() if on else None})
    where = t.args.get("where")
    return {
        "tables": sorted({tb.sql(dialect="databricks") for tb in t.find_all(exp.Table)}),
        "joins": joins,
        "where": where.this.sql() if where else None,
        "outputs": {s.alias_or_name: s.sql() for s in t.selects},
        "aggregates": sorted({a.sql() for a in t.find_all(exp.AggFunc)}),
        "group_by": [g.sql() for g in (t.args["group"].expressions if t.args.get("group") else [])],
    }


def diff_facts(o: dict, n: dict) -> dict:
    d = {k: {"old": o[k], "new": n[k]} for k in ("tables", "joins", "where", "aggregates", "group_by") if o[k] != n[k]}
    ch = {c: {"old": o["outputs"].get(c), "new": n["outputs"].get(c)}
          for c in sorted(set(o["outputs"]) | set(n["outputs"])) if o["outputs"].get(c) != n["outputs"].get(c)}
    if ch:
        d["outputs"] = ch
    return d


def downstream(sql, fqtn: str) -> list:
    try:
        rows = sql.run("SELECT DISTINCT target_table_full_name FROM system.access.table_lineage "
                       "WHERE source_table_full_name = :t AND target_table_full_name IS NOT NULL LIMIT 50", {"t": fqtn})
        return [r[0] for r in rows]
    except Exception:
        return []


def analyze(brain, sql, old_sql, new_sql, target_fqtn, prod_fqtn=None) -> dict:
    of, nf = facts(old_sql), facts(new_sql)
    d = diff_facts(of, nf)
    ds = downstream(sql, prod_fqtn or target_fqtn)
    result, engine = brain.json("analyze-sql-change", target=target_fqtn, old_facts=of, new_facts=nf,
                                structural_diff=d, downstream=ds or "unknown", old_sql=old_sql, new_sql=new_sql)
    # always add the curated rule catalog so well-known rules are tested even if the AI misses them
    seen = {r.lower() for r in result.get("business_rules", [])}
    result["business_rules"] = result.get("business_rules", []) + [
        r for r in brain.reg.bullets("domain-healthcare-claims", "Rule catalog") if r.lower() not in seen]
    result.update({"engine": engine, "structural_diff": d, "downstream": ds})
    return result
