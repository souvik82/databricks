import os
from dataclasses import dataclass, field

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def _e(name, default=None):
    return os.getenv(name, default)


@dataclass
class Config:
    catalog: str = field(default_factory=lambda: _e("SENTINEL_CATALOG", "sentinel_hc"))
    meta_schema: str = "meta"
    sandbox_schema: str = "sandbox"
    skills_dir: str = field(default_factory=lambda: _e("SENTINEL_SKILLS_DIR", os.path.join(ROOT, "skills")))
    warehouse_id: str = field(default_factory=lambda: _e("SENTINEL_WAREHOUSE_ID"))   # only needed outside notebooks
    genie_space_id: str = field(default_factory=lambda: _e("SENTINEL_GENIE_SPACE_ID"))
    llm_endpoint: str = field(default_factory=lambda: _e("SENTINEL_LLM_ENDPOINT", "databricks-claude-sonnet-4"))
    max_genie_rules: int = 12
    row_count_tolerance: float = 0.01
    pg_host: str = field(default_factory=lambda: _e("PGHOST"))      # Lakebase (optional)
    pg_db: str = field(default_factory=lambda: _e("PGDATABASE", "databricks_postgres"))
    pg_user: str = field(default_factory=lambda: _e("PGUSER"))

    def meta(self, table: str) -> str:
        return f"{self.catalog}.{self.meta_schema}.{table}"

    def sandbox(self, table: str) -> str:
        return f"{self.catalog}.{self.sandbox_schema}.{table}"
