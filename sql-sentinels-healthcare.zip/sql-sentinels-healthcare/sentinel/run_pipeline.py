"""End-to-end orchestration (notebook, job, app or CLI)."""
import uuid

from .config import Config
from .skills import SkillRegistry
from .genie_client import GenieAgent, LLM, Brain
from . import analyzer, test_generator, executor, evaluator
from .store import Store


def build_brain(cfg, w):
    reg = SkillRegistry(cfg.skills_dir)
    genie = GenieAgent(w, cfg.genie_space_id) if (w and cfg.genie_space_id) else None
    llm = LLM(w, cfg.llm_endpoint) if w else None
    return Brain(reg, genie, llm)


def run(old_sql, new_sql, target, key, sql, brain, cfg=None, w=None, trigger="notebook", prod_fqtn=None, log=print):
    cfg = cfg or Config()
    store, run_id = Store(cfg, sql, w), str(uuid.uuid4())
    brain.reg.audit.clear()

    log("1/5 Analyzing change & extracting business rules (skill: analyze-sql-change) ...")
    analysis = analyzer.analyze(brain, sql, old_sql, new_sql, cfg.sandbox(target), prod_fqtn)
    log(f"    engine={analysis['engine']} risk={analysis.get('risk_level')} rules={len(analysis['business_rules'])}")

    log("2/5 Building baseline & candidate in the sandbox schema ...")
    base, cand, bn, cn, bcols, ccols, counts = executor.build_sandbox(cfg, sql, target, old_sql, new_sql)
    log(f"    rows baseline={counts['baseline']:,} candidate={counts['candidate']:,}")

    log("3/5 Generating tests (built-in + Genie rule validation + LLM edge cases) ...")
    tests = test_generator.generate(cfg, brain, analysis, base, cand, bn, cn, bcols, ccols, key)
    log(f"    {len(tests)} tests: " + ", ".join(f"{s}={sum(t['source'] == s for t in tests)}"
                                                for s in sorted({t['source'] for t in tests})))

    log("4/5 Executing tests in parallel ...")
    results = executor.execute(sql, tests)

    log("5/5 Classifying failures & computing Trust Score ...")
    results = evaluator.classify(brain, analysis, tests, results)
    score = evaluator.trust_score(tests, results, counts)
    store.save(run_id, target, trigger, analysis, tests, results, score, list(brain.reg.audit))
    log(f"==> Trust Score {score['trust_score']}  verdict={score['verdict']}")
    return {"run_id": run_id, "analysis": analysis, "tests": tests, "results": results, "score": score}
