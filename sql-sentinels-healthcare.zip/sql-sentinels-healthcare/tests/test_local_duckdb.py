"""Offline end-to-end check of the whole pipeline (no Databricks needed): DuckDB stands in for Spark SQL and a
FakeBrain stands in for Genie/LLM (it still renders every skill file, so prompts + placeholders are validated).
Run:  pip install duckdb sqlglot pandas numpy && python tests/test_local_duckdb.py"""
import os
import re
import sys

import duckdb

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)
from sentinel.config import Config
from sentinel.sqlx import _Base
from sentinel.skills import SkillRegistry
from sentinel.synth_claims import generate
from sentinel.run_pipeline import run


class DuckSQL(_Base):
    def __init__(self, con):
        self.con = con

    def run(self, stmt, params=None):
        stmt = stmt.replace("current_timestamp()", "current_timestamp")
        stmt = stmt.replace("sentinel_hc.information_schema.columns", "information_schema.columns")  # DuckDB shim
        stmt = re.sub(r":(p\d+_\d+|[a-z_]+)\b", r"$\1", stmt) if params else stmt
        cur = self.con.cursor()
        cur.execute(stmt, params or None) if params else cur.execute(stmt)
        return [list(r) for r in cur.fetchall()] if cur.description else []


class FakeBrain:
    """Deterministic stand-in for Genie/LLM. Uses the real SkillRegistry to render real prompts."""
    def __init__(self, reg):
        self.reg = reg

    def json(self, name, **v):
        prompt = self.reg.render(name, **v)
        self.reg.record(name, prompt, "fake")
        if name == "analyze-sql-change":
            return {"change_summary": "Claim pricing / eligibility logic changed.", "risk_level": "HIGH",
                    "business_rules": ["Every output row must be covered by a member eligibility span that contains "
                                       "the service_from_date and has the same plan_id as the output row."],
                    "risky_changes": ["join predicate / filter changes"]}, "genie"
        if name == "edge-case-tests":
            return [{"name": "No NULL plan_id", "sql": f"SELECT COUNT(*) AS violations FROM {v['candidate_table']} "
                     "WHERE plan_id IS NULL", "severity": "high", "rationale": "unmatched eligibility"}], "llm"
        if name == "classify-failures":
            import json
            failed = json.loads(v["failed"])
            intended = "intended" in v["change_summary"]
            return [{"test_id": f["test_id"], "classification": "expected_change" if intended and f["category"] == "structural" else "regression",
                     "explanation": "fake"} for f in failed], "llm"

    def sql(self, name, rule, candidate_table, baseline_table):
        self.reg.record(name, self.reg.render(name, rule=rule, candidate_table=candidate_table,
                                              baseline_table=baseline_table), "fake")
        c, r = candidate_table, rule.lower()
        if "voided" in r:
            return f"SELECT COUNT(*) AS violations FROM {c} WHERE claim_status = 'VOID'", "genie"
        if "exactly once" in r:
            return f"SELECT COUNT(*) - COUNT(DISTINCT claim_line_key) AS violations FROM {c}", "genie"
        if "eligibility span" in r:
            return (f"SELECT COUNT(*) AS violations FROM {c} s WHERE NOT EXISTS (SELECT 1 FROM sentinel_hc.raw.member_eligibility e "
                    "WHERE e.member_id = s.member_id AND e.plan_id = s.plan_id AND s.service_from_date BETWEEN e.eff_date AND e.term_date)"), "genie"
        if "exceed billed" in r:
            return f"SELECT COUNT(*) AS violations FROM {c} WHERE allowed_amount > billed_amount", "genie"
        if "contracted fee" in r:
            return (f"SELECT COUNT(*) AS violations FROM {c} s JOIN sentinel_hc.raw.ref_cpt f ON f.cpt_code = s.cpt_code "
                    "WHERE s.allowed_amount > f.fee_schedule_amount * s.units + 0.001"), "genie"
        if "must equal allowed" in r:
            return f"SELECT COUNT(*) AS violations FROM {c} WHERE ABS(plan_paid_amount + member_cost_share - allowed_amount) > 0.005", "genie"
        if "denied lines" in r:
            return f"SELECT COUNT(*) AS violations FROM {c} WHERE claim_status='DENIED' AND (allowed_amount <> 0 OR plan_paid_amount <> 0)", "genie"
        return None, None


def load(con):
    con.execute("ATTACH ':memory:' AS sentinel_hc")
    for s in ("raw", "silver", "gold", "sandbox", "meta"):
        con.execute(f"CREATE SCHEMA sentinel_hc.{s}")
    for name, df in generate(n_members=400, n_providers=60, n_claims=3000).items():
        cols = ", ".join(f"CAST({c} AS DATE) AS {c}" if c.endswith("_date") else c for c in df.columns)
        con.register("tmp_df", df)
        con.execute(f"CREATE TABLE sentinel_hc.raw.{name} AS SELECT {cols} FROM tmp_df")
        con.unregister("tmp_df")
    ddl = open(os.path.join(ROOT, "ddl", "03_create_meta_tables.sql")).read()
    ddl = re.sub(r"COMMENT\s+'[^']*'", "", ddl).replace("USING DELTA", "")
    for stmt in [s for s in ddl.split(";") if s.strip()]:
        con.execute(stmt)


def sql_file(n):
    return open(os.path.join(ROOT, "sql", "business", n)).read()


if __name__ == "__main__":
    con = duckdb.connect()
    load(con)
    sql, cfg = DuckSQL(con), Config()
    brain = FakeBrain(SkillRegistry(cfg.skills_dir))
    v1 = sql_file("silver_claim_line_v1.sql")
    con.execute(f"CREATE TABLE sentinel_hc.silver.claim_line_enriched AS {v1}")

    expect = {}
    for label, f in [("v1 vs v1 (no change)", "silver_claim_line_v1.sql"),
                     ("v1 vs v3 (intended additive change)", "silver_claim_line_v3_intended.sql"),
                     ("v1 vs v2 (3 injected defects)", "silver_claim_line_v2_defects.sql")]:
        print(f"\n######## {label}")
        new = sql_file(f)
        if "v3" in f:
            brain_json = brain.json
            brain.json = lambda n, **v: (lambda r: ({**r[0], "change_summary": "intended additive change"}, r[1]) if n == "analyze-sql-change" else r)(brain_json(n, **v))
        r = run(v1, new, "silver_claim_line", "claim_line_key", sql, brain, cfg, None, "local-test", log=lambda m: None)
        if "v3" in f:
            brain.json = brain_json
        expect[label] = r["score"]
        by = {t["test_id"]: t for t in r["tests"]}
        for x in r["results"]:
            if x["outcome"] != "pass":
                print(f"  {x['outcome'].upper():5} [{by[x['test_id']]['category']:15}] {by[x['test_id']]['name'][:70]:70} v={x['violations']} {x['classification']}")
        print("  ->", r["score"], f"({len(r['tests'])} tests)")

    print("\n######## gold cascade (candidate silver feeds gold)")
    gold = sql_file("gold_claims_kpi_monthly.sql")
    r = run(gold.replace("{{silver}}", "sentinel_hc.silver.claim_line_enriched"),
            gold.replace("{{silver}}", "sentinel_hc.sandbox.silver_claim_line_candidate"),
            "gold_claims_kpi_monthly", "service_month,plan_type", sql, brain, cfg, None, "local-test", log=lambda m: None)
    print("  ->", r["score"])
    print("\nmeta rows:", {t: con.execute(f"select count(*) from sentinel_hc.meta.{t}").fetchone()[0]
                          for t in ("test_runs", "test_results", "test_cases", "change_analysis", "prompt_audit")})
    s = {k: v["verdict"] for k, v in expect.items()}
    assert s["v1 vs v1 (no change)"] == "SAFE", s
    assert s["v1 vs v2 (3 injected defects)"] == "BLOCK", s
    print("\nASSERTIONS OK:", s)
