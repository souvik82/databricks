-- AI/BI (Lakeview) dashboard datasets
-- 1 Trust Score trend
SELECT date_trunc('day', started_at) AS day, target, avg(trust_score) AS trust_score FROM sentinel_hc.meta.test_runs GROUP BY 1,2 ORDER BY 1;
-- 2 Verdict mix
SELECT verdict, count(*) AS runs FROM sentinel_hc.meta.test_runs GROUP BY verdict;
-- 3 Pass rate by category
SELECT category, round(100*avg(CASE WHEN outcome='pass' THEN 1 ELSE 0 END),1) AS pass_rate FROM sentinel_hc.meta.test_results GROUP BY category;
-- 4 Regressions caught
SELECT count(DISTINCT run_id) AS runs_with_regressions FROM sentinel_hc.meta.test_results WHERE classification='regression' AND outcome='fail';
-- 5 Latest run: failed tests with AI explanation
SELECT r.category, r.name, r.severity, r.violations, r.classification, r.ai_explanation
FROM sentinel_hc.meta.test_results r JOIN (SELECT run_id FROM sentinel_hc.meta.test_runs ORDER BY started_at DESC LIMIT 1) l USING (run_id)
WHERE r.outcome <> 'pass' ORDER BY CASE r.severity WHEN 'critical' THEN 1 WHEN 'high' THEN 2 ELSE 3 END;
-- 6 Test source mix (builtin / genie / llm)
SELECT source, count(*) AS tests FROM sentinel_hc.meta.test_cases GROUP BY source;
-- 7 Prompts by skill version (governance)
SELECT skill_name, skill_version, engine, count(*) AS prompts FROM sentinel_hc.meta.prompt_audit GROUP BY ALL;
