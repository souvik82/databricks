-- Gold: monthly KPIs by plan type. {{silver}} is replaced at run time:
--   baseline  -> sentinel_hc.silver.claim_line_enriched (production)
--   candidate -> sentinel_hc.sandbox.silver_claim_line_candidate (impact cascade)
SELECT
  service_month,
  plan_type,
  COUNT(DISTINCT claim_id)                                   AS claim_count,
  COUNT(*)                                                   AS line_count,
  COUNT(DISTINCT member_id)                                  AS claimant_count,
  SUM(billed_amount)                                         AS billed_amount,
  SUM(allowed_amount)                                        AS allowed_amount,
  SUM(plan_paid_amount)                                      AS plan_paid_amount,
  SUM(member_cost_share)                                     AS member_cost_share,
  ROUND(SUM(plan_paid_amount) / COUNT(DISTINCT member_id), 2) AS avg_paid_per_claimant,
  ROUND(SUM(CASE WHEN claim_status = 'DENIED' THEN 1 ELSE 0 END) * 1.0 / COUNT(*), 4) AS denial_rate
FROM {{silver}}
GROUP BY service_month, plan_type
