-- Silver: claim-line grain, enriched + priced. CANDIDATE v2 (contains 3 injected defects for the demo).
WITH latest_header AS (            -- R1: only the latest adjudication version of each claim
  SELECT * FROM sentinel_hc.raw.claim_header
  QUALIFY ROW_NUMBER() OVER (PARTITION BY claim_id ORDER BY claim_version DESC) = 1
),
priced AS (
  SELECT
    h.claim_id, l.line_number, h.member_id, e.plan_id, p.plan_type,
    p.copay_pcp, p.copay_specialist, p.coinsurance_pct,
    h.provider_id, pr.network_status, pr.specialty, h.claim_type, h.claim_status,
    h.service_from_date, l.cpt_code, c.cpt_category, l.units, l.billed_amount,
    -- R4: allowed = lesser of billed and contracted fee x units; denied lines allow nothing
    CASE WHEN h.claim_status = 'DENIED' THEN 0
         ELSE l.billed_amount END AS allowed_amount   -- DEFECT 3: contracted fee cap ignored
  FROM latest_header h
  JOIN sentinel_hc.raw.claim_line l
    ON l.claim_id = h.claim_id AND l.claim_version = h.claim_version
  JOIN sentinel_hc.raw.member_eligibility e   -- R2: member must be covered on the date of service
    ON e.member_id = h.member_id          -- DEFECT 1: coverage date predicate dropped (fan-out)
  JOIN sentinel_hc.raw.plan p      ON p.plan_id = e.plan_id
  JOIN sentinel_hc.raw.provider pr ON pr.provider_id = h.provider_id
  JOIN sentinel_hc.raw.ref_cpt c   ON c.cpt_code = l.cpt_code
  -- DEFECT 2: VOID filter removed
),
shared AS (                         -- R5: member cost share (copay for E&M, coinsurance otherwise; OON doubles coinsurance)
  SELECT *,
    LEAST(allowed_amount,
      CASE WHEN cpt_category = 'E&M'
             THEN CASE WHEN specialty = 'PRIMARY CARE' THEN copay_pcp ELSE copay_specialist END
           ELSE allowed_amount * LEAST(1.0, coinsurance_pct * CASE WHEN network_status = 'OUT' THEN 2 ELSE 1 END)
      END) AS member_cost_share
  FROM priced
)
SELECT
  concat_ws('-', claim_id, CAST(line_number AS STRING)) AS claim_line_key,
  claim_id, line_number, member_id, plan_id, plan_type, provider_id, network_status, specialty,
  claim_type, claim_status, service_from_date,
  CAST(date_trunc('month', service_from_date) AS DATE) AS service_month,
  cpt_code, cpt_category, units, billed_amount, allowed_amount, member_cost_share,
  allowed_amount - member_cost_share AS plan_paid_amount   -- R6: plan paid = allowed - member share
FROM shared
