CREATE TABLE IF NOT EXISTS sentinel_hc.meta.change_analysis (
  run_id STRING, target STRING, engine STRING, change_summary STRING, risk_level STRING,
  analysis_json STRING, created_at TIMESTAMP
) USING DELTA COMMENT 'AI analysis of each SQL change: business summary, risk level, structural diff';

CREATE TABLE IF NOT EXISTS sentinel_hc.meta.test_cases (
  run_id STRING, test_id STRING, category STRING, name STRING, sql_text STRING, severity STRING,
  source STRING COMMENT 'builtin | genie | llm', rationale STRING, sample_sql STRING
) USING DELTA COMMENT 'Generated regression tests (each is a SELECT returning integer column violations)';

CREATE TABLE IF NOT EXISTS sentinel_hc.meta.test_results (
  run_id STRING, test_id STRING, category STRING, name STRING, severity STRING,
  outcome STRING COMMENT 'pass | fail | error', violations BIGINT,
  classification STRING COMMENT 'expected_change | regression | data_issue',
  ai_explanation STRING, sample_json STRING, duration_ms INT, error STRING
) USING DELTA COMMENT 'One row per executed test';

CREATE TABLE IF NOT EXISTS sentinel_hc.meta.test_runs (
  run_id STRING, target STRING, trigger STRING, started_at TIMESTAMP, trust_score INT,
  verdict STRING COMMENT 'SAFE >=90, REVIEW 70-89, BLOCK <70', pass_rate DOUBLE, coverage DOUBLE,
  unexplained_pct DOUBLE
) USING DELTA COMMENT 'One row per regression run';

CREATE TABLE IF NOT EXISTS sentinel_hc.meta.prompt_audit (
  run_id STRING, skill_name STRING, skill_version STRING COMMENT 'sha of the skill file',
  engine STRING COMMENT 'genie | llm', prompt_text STRING, created_at TIMESTAMP
) USING DELTA COMMENT 'Every prompt sent to Genie / the LLM, with the skill file it came from';
