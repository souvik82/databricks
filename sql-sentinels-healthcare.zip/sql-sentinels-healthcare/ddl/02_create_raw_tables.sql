CREATE OR REPLACE TABLE sentinel_hc.raw.plan (
  plan_id          STRING        NOT NULL COMMENT 'Benefit plan identifier',
  plan_name        STRING        COMMENT 'Marketing name of the plan',
  plan_type        STRING        COMMENT 'HMO | PPO | HDHP | MEDICARE_ADV | EPO',
  deductible       DECIMAL(10,2) COMMENT 'Annual individual deductible (USD)',
  copay_pcp        DECIMAL(10,2) COMMENT 'Flat copay for primary-care E&M visits',
  copay_specialist DECIMAL(10,2) COMMENT 'Flat copay for specialist E&M visits',
  coinsurance_pct  DECIMAL(5,2)  COMMENT 'Member coinsurance on non-E&M services (0.20 = 20%)',
  oop_max          DECIMAL(10,2) COMMENT 'Annual out-of-pocket maximum (USD)',
  CONSTRAINT pk_plan PRIMARY KEY (plan_id)
) USING DELTA COMMENT 'Benefit plan design';

CREATE OR REPLACE TABLE sentinel_hc.raw.member (
  member_id  STRING NOT NULL COMMENT 'Synthetic member identifier',
  gender     STRING COMMENT 'F | M',
  birth_date DATE   COMMENT 'Date of birth (synthetic)',
  state      STRING COMMENT 'US state of residence',
  zip3       STRING COMMENT '3-digit ZIP prefix',
  CONSTRAINT pk_member PRIMARY KEY (member_id)
) USING DELTA COMMENT 'Member demographics (synthetic)';

CREATE OR REPLACE TABLE sentinel_hc.raw.member_eligibility (
  member_id STRING NOT NULL COMMENT 'FK to member',
  plan_id   STRING NOT NULL COMMENT 'FK to plan',
  eff_date  DATE   NOT NULL COMMENT 'Coverage effective date (inclusive)',
  term_date DATE   NOT NULL COMMENT 'Coverage termination date (inclusive)',
  CONSTRAINT pk_member_elig PRIMARY KEY (member_id, plan_id, eff_date)
) USING DELTA COMMENT 'Coverage spans. A member can have several spans (plan change, gaps). Join on date of service!';

CREATE OR REPLACE TABLE sentinel_hc.raw.provider (
  provider_id    STRING NOT NULL COMMENT 'Provider identifier',
  npi            STRING COMMENT 'Synthetic National Provider Identifier',
  provider_name  STRING COMMENT 'Provider group name',
  specialty      STRING COMMENT 'PRIMARY CARE | CARDIOLOGY | ORTHOPEDICS | ...',
  network_status STRING COMMENT 'IN = in-network, OUT = out-of-network',
  state          STRING COMMENT 'Practice state',
  CONSTRAINT pk_provider PRIMARY KEY (provider_id)
) USING DELTA COMMENT 'Provider directory with network status';

CREATE OR REPLACE TABLE sentinel_hc.raw.ref_cpt (
  cpt_code            STRING NOT NULL COMMENT 'Procedure code',
  description         STRING COMMENT 'Generic procedure description',
  cpt_category        STRING COMMENT 'E&M | LAB | RADIOLOGY | SURGERY | CARDIO | THERAPY',
  fee_schedule_amount DECIMAL(10,2) COMMENT 'Contracted allowed amount per unit (USD)',
  CONSTRAINT pk_ref_cpt PRIMARY KEY (cpt_code)
) USING DELTA COMMENT 'Procedure reference and contracted fee schedule';

CREATE OR REPLACE TABLE sentinel_hc.raw.ref_icd10 (
  icd10_code   STRING NOT NULL COMMENT 'Diagnosis code',
  description  STRING COMMENT 'Diagnosis description',
  chronic_flag BOOLEAN COMMENT 'TRUE when the condition is chronic',
  CONSTRAINT pk_ref_icd10 PRIMARY KEY (icd10_code)
) USING DELTA COMMENT 'Diagnosis reference';

CREATE OR REPLACE TABLE sentinel_hc.raw.claim_header (
  claim_id          STRING NOT NULL COMMENT 'Claim identifier',
  claim_version     INT    NOT NULL COMMENT '1 = original, 2+ = adjustment. Latest version wins',
  member_id         STRING COMMENT 'FK to member',
  provider_id       STRING COMMENT 'FK to provider',
  claim_type        STRING COMMENT 'PROF = professional, INST = institutional',
  service_from_date DATE   COMMENT 'First date of service',
  service_to_date   DATE   COMMENT 'Last date of service',
  received_date     DATE   COMMENT 'Date the payer received the claim',
  claim_status      STRING COMMENT 'PAID | DENIED | PENDING | VOID',
  primary_dx        STRING COMMENT 'FK to ref_icd10',
  CONSTRAINT pk_claim_header PRIMARY KEY (claim_id, claim_version)
) USING DELTA COMMENT 'Claim headers, one row per claim version';

CREATE OR REPLACE TABLE sentinel_hc.raw.claim_line (
  claim_id           STRING NOT NULL COMMENT 'FK to claim_header',
  claim_version      INT    NOT NULL COMMENT 'FK to claim_header',
  line_number        INT    NOT NULL COMMENT 'Line sequence within the claim',
  cpt_code           STRING COMMENT 'FK to ref_cpt',
  units              INT    COMMENT 'Billed units',
  billed_amount      DECIMAL(12,2) COMMENT 'Provider billed charge for the line (USD)',
  place_of_service   STRING COMMENT 'POS code: 11 office, 21 inpatient, 22 outpatient, 81 lab',
  denial_reason_code STRING COMMENT 'Populated when the claim is DENIED',
  CONSTRAINT pk_claim_line PRIMARY KEY (claim_id, claim_version, line_number)
) USING DELTA COMMENT 'Claim service lines, one row per line per claim version';
