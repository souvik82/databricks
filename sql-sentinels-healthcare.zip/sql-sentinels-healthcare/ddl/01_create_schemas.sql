CREATE CATALOG IF NOT EXISTS sentinel_hc COMMENT 'SQL Sentinels - healthcare claims regression testing demo';
CREATE SCHEMA IF NOT EXISTS sentinel_hc.raw     COMMENT 'Source claims data (synthetic, no PHI)';
CREATE SCHEMA IF NOT EXISTS sentinel_hc.silver  COMMENT 'Cleansed, enriched claim lines (production logic)';
CREATE SCHEMA IF NOT EXISTS sentinel_hc.gold    COMMENT 'Business KPIs for finance and actuarial reporting';
CREATE SCHEMA IF NOT EXISTS sentinel_hc.sandbox COMMENT 'Throw-away baseline/candidate tables created by SQL Sentinels';
CREATE SCHEMA IF NOT EXISTS sentinel_hc.meta    COMMENT 'SQL Sentinels run history, tests, results and prompt audit';
