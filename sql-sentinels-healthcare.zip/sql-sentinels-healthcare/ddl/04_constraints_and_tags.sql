-- Informational foreign keys (not enforced by Delta, but surfaced in lineage / Genie / BI tools)
ALTER TABLE sentinel_hc.raw.member_eligibility ADD CONSTRAINT fk_elig_member FOREIGN KEY (member_id) REFERENCES sentinel_hc.raw.member(member_id);
ALTER TABLE sentinel_hc.raw.member_eligibility ADD CONSTRAINT fk_elig_plan FOREIGN KEY (plan_id) REFERENCES sentinel_hc.raw.plan(plan_id);
ALTER TABLE sentinel_hc.raw.claim_line ADD CONSTRAINT fk_line_header FOREIGN KEY (claim_id, claim_version) REFERENCES sentinel_hc.raw.claim_header(claim_id, claim_version);
ALTER TABLE sentinel_hc.raw.claim_line ADD CONSTRAINT fk_line_cpt FOREIGN KEY (cpt_code) REFERENCES sentinel_hc.raw.ref_cpt(cpt_code);
ALTER TABLE sentinel_hc.raw.claim_header ADD CONSTRAINT fk_header_provider FOREIGN KEY (provider_id) REFERENCES sentinel_hc.raw.provider(provider_id);
ALTER TABLE sentinel_hc.raw.claim_header ADD CONSTRAINT fk_header_dx FOREIGN KEY (primary_dx) REFERENCES sentinel_hc.raw.ref_icd10(icd10_code);

ALTER TABLE sentinel_hc.raw.claim_header SET TAGS ('domain' = 'healthcare', 'layer' = 'raw', 'contains_phi' = 'false');
ALTER TABLE sentinel_hc.raw.claim_line   SET TAGS ('domain' = 'healthcare', 'layer' = 'raw', 'contains_phi' = 'false');
ALTER TABLE sentinel_hc.raw.member       SET TAGS ('domain' = 'healthcare', 'layer' = 'raw', 'contains_phi' = 'false', 'synthetic' = 'true');
